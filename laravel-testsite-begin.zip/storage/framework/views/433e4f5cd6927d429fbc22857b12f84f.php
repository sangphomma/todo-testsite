<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
  <div class="flex min-h-screen w-full">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
</body>
</html>
<?php /**PATH C:\Users\PREDATOR\Desktop\@RealStart\laravel-testsite\resources\views/products/layouts.blade.php ENDPATH**/ ?>